#!/bin/bash
echo "Digite o nome do projeto:"
read projname;
GIT=`which git`
mkdir -p $projname
cd $projname
echo "O wordpress será instalado na pasta:"
pwd
wget https://wordpress.org/latest.tar.gz
tar -xzvf latest.tar.gz
rm -rf latest.tar.gz
mv wordpress/* ./
rm -rf wordpress
cd wp-content/plugins/
rm -rf akismet
rm -rf hello.php
${GIT} clone git@bitbucket.org:santins/padr-o-plugins-wordpress.git
mv padr-o-plugins-wordpress/* ./
rm -rf padr-o-plugins-wordpress
rm -rf .git
cd ..
cd themes/
rm -rf twentynineteen
rm -rf twentyseventeen
rm -rf twentysixteen
${GIT} clone git@bitbucket.org:santins/wp-theme-template-santins.git $projname
cd $projname
rm -rf .git
npm install
cd ..
cd ..
cd ..
cp wp-config-sample.php wp-config.php
echo "Agora crie o banco de dados, crie um vhost, edite o arquivo wp-config.php e se desejar trabalhar com browserSync edite gulpfile.js na pasta do tema e mude o proxy para um o vhost do projeto após rode npm run start;"
read -p "Aperte enter para sair";